import { track, wire, api, LightningElement } from 'lwc';
import getCourse from '@salesforce/apex/cardCourse.getCourse';
import getLeadsWithMultiPicklistValues from '@salesforce/apex/cardCourse.getLeadsWithMultiPicklistValues';
import { CurrentPageReference } from 'lightning/navigation';

export default class CardCourseDetails extends LightningElement {
    @track courses = [];
    // @track leads = [];
    @track error;
    @track accountId;

    // Fetch courses based on accountId from URL
    @wire(getCourse, { accountId: '$accountId' })
    wiredCourses({ error, data }) {
        if (data) {
            this.courses = data;
            this.error = undefined;
        } else {
            this.error = error;
            this.courses = [];
        }
    }

    // // Fetch Leads with multi-picklist values
    // @wire(getLeadsWithMultiPicklistValues)
    // wiredLeads({ error, data }) {
    //     if (data) {
    //         this.courses = data.map(lead => ({
    //             ...lead,
    //             LeadSourceValues: this.getMultiPicklistValues(lead.Eligibility_Criteria__c)
    //         }));
    //         this.error = undefined;
    //     } else {
    //         this.error = error;
    //         this.courses = [];
    //     }
    // }

    // getMultiPicklistValues(multiPicklistString) {
    //     if (multiPicklistString) {
    //         return multiPicklistString.split(';'); // Split the multi-picklist values by semicolon
    //     }
    //     return [];
    // }

  

    // Capture accountId from the URL
    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference?.state?.accountId) {
            this.accountId = currentPageReference.state.accountId;
        }
    }
}
