import { LightningElement, api, track } from 'lwc';
import updateStudentInquiryLead from '@salesforce/apex/UpdateStudentInquiry.updateStudentInquiryLead';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class updateStudentInquiry extends LightningElement {
    // @api recordId; // The record ID passed from the URL or parent component
    recordId='a01dL00000nkYowQAE'
    @track firstName;
    @track middleName;
    @track lastName;
    @track email;
    @track phone;
    @track dob;
    @track gender;
    @track street;
    @track country;
    @track state;
    // @track marks;

    // Handle field input changes
    handleInputChange(event) {
        const fieldName = event.target.fieldName;
        this[fieldName] = event.target.value;
    }

    // Handle form submission
    handleSuccess(event) {
        // Prepare the data to be sent to Apex
        const fieldValues = {
            'First_Name__c': this.firstName,
            'Middle_Name__c': this.middleName,
            'Last_Name__c': this.lastName,
            'Email__c': this.email,
            'Phone__c': this.phone,
            'DOB__c': this.dob,
            'Gender__c': this.gender,
            'Street__c': this.street,
            'Country__c': this.country,
            'State__c': this.state,
            // 'Marks__c': this.marks
        };

        // Remove empty fields from the map
        for (const field in fieldValues) {
            if (!fieldValues[field]) {
                delete fieldValues[field];
            }
        }

        // Call Apex to update the record
        updateStudentInquiryLead({ leadId: this.recordId, fieldValues })
            .then(result => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: result,
                        variant: 'success'
                    })
                );
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }

    // Handle form errors
    handleError(event) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message: event.detail.message,
                variant: 'error'
            })
        );
    }
}
